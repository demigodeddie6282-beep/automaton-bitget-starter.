# Automaton + Bitget: simulation-only starter

This is a beginner-friendly starter scaffold, **not a complete Automaton integration and not a profitable strategy**. It does not connect to Bitget, place exchange orders, deploy to a cloud server, or require API keys.

## Safety defaults
- Only `TRADING_MODE=simulation` is accepted. Any other mode stops the program.
- Starting balance is $2 of virtual cash.
- Maximum simulated order size is $0.25.
- Maximum realized loss threshold is $0.10 per run.
- Maximum of 4 simulated trades per run.
- Fees and slippage are estimated and included in logs.
- The Bitget adapter is a disabled placeholder; order submission always throws an error.

## Requirements
Node.js 20 or newer and npm.

## Run it
1. Unzip this folder or put its files in a GitHub repository.
2. Open a terminal in this folder.
3. Check `node --version` (must be v20+).
4. Run `npm install`.
5. Run `npm run build`.
6. Run `npm start`.
7. Review `data/trades.jsonl` and `data/summary.json`.

The program uses invented sample prices, not live market prices. It demonstrates software behaviour only; a simulation cannot establish that a strategy will be profitable.

## Next phase
Before adding even Bitget demo connectivity, inspect the existing Automaton source, run tests, and review the security boundaries. Keep credentials out of source code and chat. Never grant withdrawal permissions to a trading API key. Live trading and deployment require a separate explicit approval.
