export interface Config {
  mode: "simulation";
  startingBalanceUsd: number;
  maxOrderUsd: number;
  maxDailyLossUsd: number;
  maxTradesPerRun: number;
  feeRate: number;
  slippageRate: number;
}

function numberSetting(name: string, fallback: number, allowZero = false): number {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === "") return fallback;
  const value = Number(raw);
  if (!Number.isFinite(value) || (allowZero ? value < 0 : value <= 0)) {
    throw new Error(`${name} must be ${allowZero ? "zero or greater" : "a positive number"}.`);
  }
  return value;
}

export function loadConfig(): Config {
  const requestedMode = process.env.TRADING_MODE ?? "simulation";
  // Fail closed: neither demo nor live execution is implemented in this starter.
  if (requestedMode !== "simulation") {
    throw new Error(`Unsafe mode '${requestedMode}'. This starter only allows TRADING_MODE=simulation.`);
  }

  const config: Config = {
    mode: "simulation",
    startingBalanceUsd: numberSetting("STARTING_BALANCE_USD", 2),
    maxOrderUsd: numberSetting("MAX_ORDER_USD", 0.25),
    maxDailyLossUsd: numberSetting("MAX_DAILY_LOSS_USD", 0.10),
    maxTradesPerRun: Math.floor(numberSetting("MAX_TRADES_PER_RUN", 4)),
    feeRate: numberSetting("FEE_RATE", 0.001, true),
    slippageRate: numberSetting("SLIPPAGE_RATE", 0.001, true)
  };

  if (config.maxOrderUsd > config.startingBalanceUsd) {
    throw new Error("MAX_ORDER_USD cannot exceed STARTING_BALANCE_USD.");
  }
  if (config.maxTradesPerRun < 1) throw new Error("MAX_TRADES_PER_RUN must be at least 1.");
  if (config.feeRate > 0.05 || config.slippageRate > 0.05) {
    throw new Error("Fee/slippage estimates above 5% are rejected; check the configuration.");
  }
  return config;
}
