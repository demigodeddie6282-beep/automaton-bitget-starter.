export type Side = "buy" | "sell";

export interface OrderRequest {
  side: Side;
  notionalUsd: number;
  referencePrice: number;
  reason: string;
}

export interface SimulatedTrade {
  timestamp: string;
  mode: "simulation";
  side: Side;
  notionalUsd: number;
  referencePrice: number;
  fillPrice: number;
  quantity: number;
  feeUsd: number;
  slippageCostUsd: number;
  reason: string;
  cashBalanceAfterUsd: number;
  realizedPnlUsd: number;
}

export interface RiskState {
  tradesThisRun: number;
  realizedPnlUsd: number;
  halted: boolean;
  haltReason?: string;
}
