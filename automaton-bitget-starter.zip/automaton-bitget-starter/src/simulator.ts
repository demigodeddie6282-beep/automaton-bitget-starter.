import fs from "node:fs";
import path from "node:path";
import type { Config } from "./config.js";
import { checkOrder } from "./risk.js";
import type { OrderRequest, RiskState, SimulatedTrade } from "./types.js";

export class Simulator {
  private cashBalanceUsd: number;
  private readonly config: Config;
  private readonly state: RiskState = { tradesThisRun: 0, realizedPnlUsd: 0, halted: false };
  private readonly trades: SimulatedTrade[] = [];
  private positionQuantity = 0;
  private averageEntryPrice = 0;

  constructor(config: Config) {
    this.config = config;
    this.cashBalanceUsd = config.startingBalanceUsd;
  }

  execute(order: OrderRequest): SimulatedTrade | null {
    const decision = checkOrder(order, this.state, this.cashBalanceUsd, this.config);
    if (!decision.allowed) {
      console.log(`BLOCKED: ${decision.reason}`);
      return null;
    }

    const quantity = order.notionalUsd / order.referencePrice;
    const fillPrice = order.side === "buy"
      ? order.referencePrice * (1 + this.config.slippageRate)
      : order.referencePrice * (1 - this.config.slippageRate);
    const feeUsd = order.notionalUsd * this.config.feeRate;
    const slippageCostUsd = Math.abs(fillPrice - order.referencePrice) * quantity;
    let realizedPnlUsd = 0;

    if (order.side === "buy") {
      const totalDebit = order.notionalUsd + feeUsd + slippageCostUsd;
      if (totalDebit > this.cashBalanceUsd) {
        console.log("BLOCKED: exact estimated costs would make virtual cash negative.");
        return null;
      }
      const oldCost = this.positionQuantity * this.averageEntryPrice;
      this.positionQuantity += quantity;
      this.averageEntryPrice = this.positionQuantity > 0 ? (oldCost + order.notionalUsd) / this.positionQuantity : 0;
      this.cashBalanceUsd -= totalDebit;
    } else {
      if (quantity > this.positionQuantity + 1e-12) {
        console.log("BLOCKED: cannot sell more than the simulated position.");
        return null;
      }
      const proceeds = order.notionalUsd - feeUsd - slippageCostUsd;
      realizedPnlUsd = proceeds - quantity * this.averageEntryPrice;
      this.cashBalanceUsd += proceeds;
      this.positionQuantity -= quantity;
      if (this.positionQuantity < 1e-12) {
        this.positionQuantity = 0;
        this.averageEntryPrice = 0;
      }
      this.state.realizedPnlUsd += realizedPnlUsd;
      if (this.state.realizedPnlUsd <= -this.config.maxDailyLossUsd) {
        this.state.halted = true;
        this.state.haltReason = "Maximum loss threshold reached after simulated trade.";
      }
    }

    this.state.tradesThisRun += 1;
    const trade: SimulatedTrade = {
      timestamp: new Date().toISOString(), mode: "simulation", side: order.side,
      notionalUsd: Number(order.notionalUsd.toFixed(6)),
      referencePrice: Number(order.referencePrice.toFixed(6)),
      fillPrice: Number(fillPrice.toFixed(6)), quantity: Number(quantity.toFixed(10)),
      feeUsd: Number(feeUsd.toFixed(8)), slippageCostUsd: Number(slippageCostUsd.toFixed(8)),
      reason: order.reason, cashBalanceAfterUsd: Number(this.cashBalanceUsd.toFixed(8)),
      realizedPnlUsd: Number(realizedPnlUsd.toFixed(8))
    };
    this.trades.push(trade);
    console.log(`SIM ${trade.side.toUpperCase()} $${trade.notionalUsd.toFixed(2)} | fee $${trade.feeUsd.toFixed(5)} | slippage ~$${trade.slippageCostUsd.toFixed(5)} | cash $${this.cashBalanceUsd.toFixed(4)}`);
    return trade;
  }

  saveResults(): void {
    const dataDir = path.resolve("data");
    fs.mkdirSync(dataDir, { recursive: true });
    fs.writeFileSync(path.join(dataDir, "trades.jsonl"), this.trades.map(t => JSON.stringify(t)).join("\n") + (this.trades.length ? "\n" : ""), "utf8");
    const summary = {
      mode: "simulation", startingBalanceUsd: this.config.startingBalanceUsd,
      endingCashBalanceUsd: Number(this.cashBalanceUsd.toFixed(8)),
      openPositionQuantity: Number(this.positionQuantity.toFixed(10)),
      averageEntryPriceUsd: Number(this.averageEntryPrice.toFixed(8)),
      trades: this.trades.length, realizedPnlUsd: Number(this.state.realizedPnlUsd.toFixed(8)),
      estimatedFeesUsd: Number(this.trades.reduce((sum, trade) => sum + trade.feeUsd, 0).toFixed(8)),
      estimatedSlippageUsd: Number(this.trades.reduce((sum, trade) => sum + trade.slippageCostUsd, 0).toFixed(8)),
      note: "Invented sample prices; not live market data. No exchange orders were placed."
    };
    fs.writeFileSync(path.join(dataDir, "summary.json"), JSON.stringify(summary, null, 2), "utf8");
    console.log("\nSummary:\n" + JSON.stringify(summary, null, 2));
  }
}
