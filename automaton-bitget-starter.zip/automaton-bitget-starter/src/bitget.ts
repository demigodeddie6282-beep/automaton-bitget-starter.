/**
 * DISABLED SAFETY PLACEHOLDER.
 * No Bitget API client or order-submission code is present.
 * Demo connectivity should only be added after reviewing Automaton source,
 * passing simulation tests, and obtaining explicit user approval.
 * Never commit API secrets. Any future trading key must have withdrawals disabled.
 */
export class BitgetAdapter {
  constructor() {
    console.log("Bitget connectivity is disabled; simulation-only starter.");
  }

  placeOrder(): never {
    throw new Error("Exchange orders are disabled. This starter has no Bitget connectivity.");
  }
}
