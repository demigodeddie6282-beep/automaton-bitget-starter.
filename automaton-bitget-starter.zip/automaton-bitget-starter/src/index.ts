import { loadConfig } from "./config.js";
import { Simulator } from "./simulator.js";
import type { OrderRequest } from "./types.js";

function main(): void {
  const config = loadConfig();
  console.log("Automaton + Bitget safe starter");
  console.log(`Mode: ${config.mode}`);
  console.log(`Starting virtual balance: $${config.startingBalanceUsd.toFixed(2)}`);
  console.log("Bitget connection: DISABLED | Live orders: DISABLED\n");

  const simulator = new Simulator(config);
  // Invented prices for testing only. No network calls or real market data.
  const orders: OrderRequest[] = [
    { side: "buy", notionalUsd: 0.20, referencePrice: 100, reason: "sample test entry" },
    { side: "sell", notionalUsd: 0.20, referencePrice: 101, reason: "sample test exit" },
    { side: "buy", notionalUsd: 0.20, referencePrice: 99, reason: "sample test entry" },
    { side: "sell", notionalUsd: 0.20, referencePrice: 102, reason: "sample test exit" },
    { side: "buy", notionalUsd: 0.80, referencePrice: 98, reason: "safety test: oversized order should be blocked" }
  ];
  for (const order of orders) simulator.execute(order);
  simulator.saveResults();
}

try {
  main();
} catch (error) {
  console.error("STOPPED safely:", error instanceof Error ? error.message : error);
  process.exitCode = 1;
}
