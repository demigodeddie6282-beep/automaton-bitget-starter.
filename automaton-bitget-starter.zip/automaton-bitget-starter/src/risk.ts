import type { Config } from "./config.js";
import type { OrderRequest, RiskState } from "./types.js";

export interface RiskDecision { allowed: boolean; reason: string }

export function checkOrder(
  order: OrderRequest,
  state: RiskState,
  cashBalanceUsd: number,
  config: Config
): RiskDecision {
  if (config.mode !== "simulation") return { allowed: false, reason: "Only simulation mode is permitted." };
  if (state.halted) return { allowed: false, reason: state.haltReason ?? "Trading is halted." };
  if (state.tradesThisRun >= config.maxTradesPerRun) return { allowed: false, reason: "Maximum trades per run reached." };
  if (!Number.isFinite(order.notionalUsd) || order.notionalUsd <= 0) return { allowed: false, reason: "Order size must be positive and finite." };
  if (order.notionalUsd > config.maxOrderUsd) return { allowed: false, reason: `Order exceeds maximum $${config.maxOrderUsd.toFixed(2)}.` };
  if (!Number.isFinite(order.referencePrice) || order.referencePrice <= 0) return { allowed: false, reason: "Reference price must be positive and finite." };
  if (state.realizedPnlUsd <= -config.maxDailyLossUsd) return { allowed: false, reason: "Maximum loss threshold reached." };
  const estimatedDebit = order.notionalUsd * (1 + config.feeRate + config.slippageRate);
  if (order.side === "buy" && estimatedDebit > cashBalanceUsd) return { allowed: false, reason: "Insufficient virtual cash including estimated costs." };
  return { allowed: true, reason: "Risk checks passed for simulation." };
}
